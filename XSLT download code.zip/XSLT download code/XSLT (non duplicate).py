
#Code to download only active xslt files(non duplicate)

#first install cx_Oracle module using pip
import cx_Oracle
import os

# Connect to the Oracle database
conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

# Define the output directory path
output_dir = r'C:\\Users\\saikiran.kurmapu\\OneDrive - Argo Group\\W_ALL\\Python\\XSLT_download5'

# Define the query to select the XSLT NCLOB files and their names
query = """
    select tftv.XSL_FO as XSL, tftv.XSL_FO_FILENAME as XSL_FILE, tfrbux.business_unit_code as Business_Unit 
from tbli_form_template_version tftv, TBLI_FORM_RULE_BUS_UNIT_XREF tfrbux, tbli_form_rule_template_xref tfrtx, tbli_form_attachment_rule tfar
where tftv.form_template_id = tfrtx.form_template_id
and tfrtx.form_rule_id = tfrbux.form_rule_id
and tfrbux.form_rule_id = tfar.form_rule_id
and tfar.status = 'AV'
and tfrbux.exp_with_rateset_release is null
and tftv.xsl_fo is not null
and tfrbux.business_unit_code in ('GR')
order by 2
"""

# Execute the query
cursor = conn.cursor()
cursor.execute(query)

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Keep track of downloaded file names
downloaded_files = []

# Iterate over the query result
for row in cursor:
    # Extract the XSLT NCLOB file and its name
    XSL = row[0].read()
    XSL_FILE = row[1]

    # Skip downloading if the file has already been downloaded
    if XSL_FILE in downloaded_files:
        continue

    # Save the XSLT NCLOB file with its respective name to the output directory
    if XSL_FILE:
        file_path = os.path.join(output_dir, XSL_FILE)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(XSL)
            

        # Add the downloaded file name to the list
        downloaded_files.append(XSL_FILE)
