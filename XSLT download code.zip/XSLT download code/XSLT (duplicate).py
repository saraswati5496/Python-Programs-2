#code to download only active xslt files(duplicate files also)

#first install cx_Oracle module using pip
import cx_Oracle
import os

# Connect to the Oracle database
conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

# Define the output directory path
output_dir = r'C:\\Users\\saikiran.kurmapu\\OneDrive - Argo Group\\W_ALL\\Python\\XSLT_download_duplicate'

# Define the query to select the XSLT NCLOB files and their names
query = """
   select tftv.XSL_FO as XSL, tftv.XSL_FO_FILENAME as XSL_FILE, tfrbux.business_unit_code as Business_Unit 
from tbli_form_template_version tftv, TBLI_FORM_RULE_BUS_UNIT_XREF tfrbux, tbli_form_rule_template_xref tfrtx, tbli_form_attachment_rule tfar
where tftv.form_template_id = tfrtx.form_template_id
and tfrtx.form_rule_id = tfrbux.form_rule_id
and tfrbux.form_rule_id = tfar.form_rule_id
and tfar.status = 'AV'
and tfrbux.exp_with_rateset_release is null
and tftv.xsl_fo is not null
and tfrbux.business_unit_code in ('GR')
order by 2
"""

# Execute the query
cursor = conn.cursor()
cursor.execute(query)

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Iterate over the query result
for row in cursor:
    # Extract the XSLT NCLOB file and its name
    XSL_FO = row[0].read()
    XSL_FO_FILENAME = row[1]
    
    # Save the XSLT NCLOB file with a unique name to the output directory
    if XSL_FO_FILENAME:
        # Generate a unique file name by appending a counter if the file already exists
        file_path = os.path.join(output_dir, XSL_FO_FILENAME)
        counter = 1
        while os.path.exists(file_path):
            file_name, file_ext = os.path.splitext(XSL_FO_FILENAME)
            new_file_name = f"{file_name}_{counter}{file_ext}"
            file_path = os.path.join(output_dir, new_file_name)
            counter += 1
        
        # Save the XSLT NCLOB file with the unique file name
        with open(file_path, 'wb') as f:
            f.write(XSL_FO.encode('utf-8'))
